import 'package:flutter/material.dart';

class StatString
{

  static var colorOrange=Colors.orange[900];
  static var colorLightOrange=Color(0xFFffcdd2);



}